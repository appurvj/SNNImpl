
/**
 * This enumerator just lists the various types of neurons that make up a network
 * @author Appurv Jain and Amrith Akula
 */
public enum SNType {
    INPUT, HIDDEN, OUTPUT;
    public String toString(){
        return super.toString();
    }
}
